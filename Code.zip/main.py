import random
import gameframework
import start_state

from pico2d import *

gameframework.run(start_state)
# 게임 오브젝트 클래스의 정의들